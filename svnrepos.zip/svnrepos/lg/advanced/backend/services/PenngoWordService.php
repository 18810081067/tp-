<?php
namespace backend\services;

use backend\models\PenngoWord;

class PenngoWordService extends PenngoWord{

   
}
