<?php
namespace backend\services;

use backend\models\Usersize;

class UsersizeService extends Usersize{

   
}
