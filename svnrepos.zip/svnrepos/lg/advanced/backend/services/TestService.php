<?php
namespace backend\services;

use backend\models\Test;

class TestService extends Test{

   
}
