<?php
namespace backend\services;

use backend\models\AdminMenu;

class AdminMenuService extends AdminMenu{

   
}
