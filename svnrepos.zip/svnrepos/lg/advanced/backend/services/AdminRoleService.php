<?php
namespace backend\services;

use backend\models\AdminRole;

class AdminRoleService extends AdminRole{

   
}
